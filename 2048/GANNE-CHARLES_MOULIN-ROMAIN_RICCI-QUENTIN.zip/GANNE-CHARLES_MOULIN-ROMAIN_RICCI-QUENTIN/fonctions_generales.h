#include <stdio.h>
#include <stdbool.h>

bool normal();
bool duo();
bool puzzle();
